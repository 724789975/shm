#ifndef __SHARE_MEM_CONTAINER_MAP_ALLOCTOR_H__
#define __SHARE_MEM_CONTAINER_MAP_ALLOCTOR_H__

#include "shm_container_less.h"
#include "shm_pool.h"

namespace ShareMemoryContainer
{
	template<typename K, typename V>
	class KVPair
	{
	public:
		K first;
		V second;
	};

	template<typename K, typename V>
	class _KVPair
	{
	public:
		const K first;
		V second;
	};

	template<bool is_const, typename K, typename V>
	class TreeInfo : public std::conditional<is_const, _KVPair<K, V>, KVPair<K, V>>::type
	{
	public:
		typedef typename std::conditional<is_const, _KVPair<K, V>,  KVPair<K, V>>::type Pair4Iterator;

		typedef typename std::conditional<is_const, const unsigned int, unsigned int>::type IndexType;
		IndexType									m_dwMyIndex;		//���������ƫ��
		unsigned int								m_dwHeight;			//����
		unsigned int								m_dwParentIndex;
		unsigned int								m_dwLeftIndex;
		unsigned int								m_dwRightIndex;
	};

	template<typename K, typename V>
	class MapAllocator
	{
	public:
		typedef KVPair<K, V> ValueType;
		typedef _KVPair<K, V> _ValueType;

		typedef K CompareType;

		typedef TreeInfo<false, K, V> NodeData;
		typedef TreeInfo<true, K, V> Node;
		static const K& get_compare_val(const ValueType& refPair) { return refPair.first; }
		static const K& get_compare_val(const _ValueType& refPair) { return refPair.first; }
	};




};

#endif //__SHARE_MEM_CONTAINER_MAP_ALLOCTOR_H__
