#ifndef __SHARE_MEM_CONTAINER_TREE_H__
#define __SHARE_MEM_CONTAINER_TREE_H__

#include "shm_container_map_alloctor.h"
#include "shm_container_less.h"
#include "shm_pool.h"

#include <iostream>
#include <exception>
#include <type_traits>
#include <algorithm>
#include <deque>

//K, V ��֧��POD����
namespace ShareMemoryContainer
{
	template<typename Ty, unsigned int dwMaxNum>
	class allocator
	{
	public:
		enum { CAPACITY = dwMaxNum, };
		typedef typename Ty::CompareType CompareType;
		typedef typename Ty::ValueType ValueType;
		typedef typename Ty::_ValueType _ValueType;
	
		static const CompareType& get_compare_val(const _ValueType& value_type);
	};

	template<typename Ty, unsigned int dwMaxNum>
	inline const typename allocator<Ty, dwMaxNum>::CompareType&
		allocator<Ty, dwMaxNum>::get_compare_val(
		const typename allocator<Ty, dwMaxNum>::_ValueType& value_type)
	{
		return Ty::get_compare_val(value_type);
	}

	template<typename _K, typename Alloc = allocator<MapAllocator<_K, int>, 0>, typename KeyLess = Less<_K> >
	class Tree
	{
		template<typename T, bool is_const = true>
		struct to_const_type
		{
			typedef const T Type;
		};

		template<typename T>
		struct to_const_type<T, false>
		{
			typedef T Type;
		};

		template<bool is_const>
		class TreeInfo : public std::conditional<is_const,\
			typename Alloc::_ValueType, typename Alloc::ValueType>::type
		{
			friend class Tree<_K, Alloc, KeyLess>;
		public:
		protected:
			typedef typename to_const_type<unsigned int, is_const>::Type IndexType;
			IndexType									m_dwMyIndex;		//���������ƫ��
			unsigned int								m_dwHeight;			//����
			unsigned int								m_dwParentIndex;
			unsigned int								m_dwLeftIndex;
			unsigned int								m_dwRightIndex;
		};
		
		typedef TreeInfo<false> TreeNodeData;
		typedef TreeInfo<true> TreeNode;
		
		template<bool is_const>
		class iterator_t
		{
			friend class Tree<_K, Alloc, KeyLess>;
		public:
			typedef typename to_const_type<TreeNode, is_const>::Type TreeNodeType;
			iterator_t() : m_pTreeNode(0), m_pTree(0) {}
			TreeNodeType& operator*() { return (TreeNodeType&)**(TreeNodeType*)m_pTreeNode; }
			TreeNodeType* operator->() { return m_pTreeNode; }
			bool operator==(const iterator_t& it)
			{
				return (m_pTreeNode == it.m_pTreeNode) && (m_pTree == it.m_pTree);
			}
			iterator_t<is_const>& operator++()
			{
				if (!m_pTree) { return *this; }
				if (!m_pTreeNode) { return *this; }
				m_pTreeNode = m_pTree->_GetNext(*m_pTreeNode).m_pTreeNode;
				return *this;
			}
			iterator_t operator++(int)
			{
				if (!m_pTree) { return *this; }
				if (!m_pTreeNode) { return *this; }
				iterator_t it;
				it.m_pTree = m_pTree;
				it.m_pTreeNode = m_pTreeNode;
				m_pTreeNode = m_pTree->_GetNext(*m_pTreeNode).m_pTreeNode;
				return it;
			}
			iterator_t& operator--()
			{
				if (!m_pTree) { return *this; }
				if (!m_pTreeNode) { return *this; }
				m_pTreeNode = m_pTree->_GetPrevious(*m_pTreeNode).m_pTreeNode;
				return *this;
			}
			iterator_t operator--(int)
			{
				if (!m_pTree) { return *this; }
				if (!m_pTreeNode) { return *this; }
				iterator_t it;
				it.m_pTree = m_pTree;
				it.m_pTreeNode = m_pTreeNode;
				m_pTreeNode = m_pTree->_GetPrevious(*m_pTreeNode).m_pTreeNode;
				return it;
			}
		private:
			typename to_const_type<TreeNode, is_const>::Type*					m_pTreeNode;
			typename to_const_type<Tree<_K, Alloc, KeyLess>, is_const>::Type*	m_pTree;
		};

		template<bool is_const>
		class reverse_iterator_t
		{
			friend class Tree<_K, Alloc, KeyLess>;
		public:
			typedef typename to_const_type<TreeNode, is_const>::Type TreeNodeType;
			reverse_iterator_t() : m_pTreeNode(0), m_pTree(0) {}
			TreeNodeType& operator*() { return (TreeNodeType&)**(TreeNodeType*)m_pTreeNode; }
			TreeNodeType* operator->() { return m_pTreeNode; }
			bool operator==(const reverse_iterator_t& it)
			{
				return (m_pTreeNode == it.m_pTreeNode) && (m_pTree == it.m_pTree);
			}
			reverse_iterator_t<is_const>& operator++()
			{
				if (!m_pTree) { return *this; }
				if (!m_pTreeNode) { return *this; }
				m_pTreeNode = m_pTree->_GetPrevious(*m_pTreeNode).m_pTreeNode;
				return *this;
			}
			reverse_iterator_t operator++(int)
			{
				if (!m_pTree) { return *this; }
				if (!m_pTreeNode) { return *this; }
				reverse_iterator_t it;
				it.m_pTree = m_pTree;
				it.m_pTreeNode = m_pTreeNode;
				m_pTreeNode = m_pTree->_GetPrevious(*m_pTreeNode).m_pTreeNode;
				return it;
			}
			reverse_iterator_t& operator--()
			{
				if (!m_pTree) { return *this; }
				if (!m_pTreeNode) { return *this; }
				m_pTreeNode = m_pTree->_GetNext(*m_pTreeNode).m_pTreeNode;
				return *this;
			}
			reverse_iterator_t operator--(int)
			{
				if (!m_pTree) { return *this; }
				if (!m_pTreeNode) { return *this; }
				reverse_iterator_t it;
				it.m_pTree = m_pTree;
				it.m_pTreeNode = m_pTreeNode;
				m_pTreeNode = m_pTree->_GetNext(*m_pTreeNode).m_pTreeNode;
				return it;
			}
		private:
			typename to_const_type<TreeNode, is_const>::Type*					m_pTreeNode;
			typename to_const_type<Tree<_K, Alloc, KeyLess>, is_const>::Type*	m_pTree;
		};
	public:

		typedef iterator_t<false> iterator;
		typedef iterator_t<true> const_iterator;
		typedef std::pair<iterator, bool> insert_ret;
		typedef reverse_iterator_t<false> reverse_iterator;
		typedef reverse_iterator_t<true> const_reverse_iterator;

		void create();

		insert_ret insert(const typename Alloc::ValueType& refValue);
		unsigned int erase(const _K& k);
		iterator erase(iterator it);
		iterator erase(const_iterator it);

		iterator find(const _K& k);
		iterator begin();
		const_iterator cbegin()const;
		iterator end();
		const_iterator cend()const;
		reverse_iterator rbegin();
		const_reverse_iterator crbegin()const;
		reverse_iterator rend();
		const_reverse_iterator crend()const;
		iterator lower_bound(const _K& k);
		iterator upper_bound(const _K& k);
		void clear();
		unsigned int size()const;

		void debug_info(std::ostream& os);

	private:
		/// <summary>
		/// ��ȡ�ڵ�
		/// </summary>
		/// <param name="dwIndex"></param>
		/// <returns></returns>
		TreeNode& _GetTreeNode(unsigned int dwIndex);
		const TreeNode& _GetTreeNode(unsigned int dwIndex)const;
		/// <summary>
		/// ����ڵ�
		/// </summary>
		/// <param name="refTreeNodeData"></param>
		/// <param name="dwTreeNodeIndex"></param>
		void _ConstructTreeNodeData(TreeNodeData& refTreeNodeData, unsigned int dwTreeNodeIndex);
		void _ConstructTreeNodeData(TreeNodeData& refTreeNodeData, unsigned int dwTreeNodeIndex,
			const typename Alloc::ValueType& refValueNode);
		/// <summary>
		/// ����ڵ�
		/// </summary>
		/// <returns></returns>
		unsigned int _BuyNode();
		unsigned int _BuyNode(std::ostream os);
		/// <summary>
		/// �ͷŽڵ�
		/// </summary>
		/// <param name="dwTreeNodeIndex"></param>
		/// <returns></returns>
		bool _FreeNode(unsigned int dwTreeNodeIndex);
		bool _FreeNode(unsigned int dwTreeNodeIndex, std::ostream& os);
		/// <summary>
		/// ��С�Ƚ�
		/// </summary>
		/// <param name="dwLeftNodeIndex"></param>
		/// <param name="dwRoightNodeIndex"></param>
		/// <returns></returns>
		bool _Less(unsigned int dwLeftNodeIndex, unsigned int dwRoightNodeIndex)const;
		bool _Less4K(const _K& l, const _K& r)const;
		/// <summary>
		/// k�Ƿ���ͬ
		/// </summary>
		/// <param name="l"></param>
		/// <param name="r"></param>
		/// <returns></returns>
		bool _Equal4K(const _K& l, const _K& r)const;
		/// <summary>
		/// �Ƴ��ڵ�
		/// </summary>
		/// <param name="refTreeNode"></param>
		void _RemoveNode(TreeNode& refTreeNode);
		/// <summary>
		/// ��ȡ������
		/// </summary>
		/// <param name="refTreeNode"></param>
		/// <returns></returns>
		iterator _GetIterator(TreeNode& refTreeNode);
		const_iterator _GetIterator(TreeNode& refTreeNode)const;
		/// <summary>
		/// ��ȡ������
		/// </summary>
		/// <param name="dwTreeNodeIndex"></param>
		/// <returns></returns>
		iterator _GetIterator(unsigned int dwTreeNodeIndex);
		const_iterator _GetIterator(unsigned int dwTreeNodeIndex)const;
		/// <summary>
		/// ��ȡ����
		/// </summary>
		/// <param name="dwIndex"></param>
		/// <returns></returns>
		int _GetHeight(unsigned int dwIndex);
		/// <summary>
		/// ���½ڵ�ĸ߶�
		/// </summary>
		/// <param name="refTreeNode"></param>
		/// <returns></returns>
		void _UpdateHeight(TreeNode& refTreeNode);
		/// <summary>
		/// ��ýڵ�������ֵ
		/// </summary>
		/// <param name="refTreeNode"></param>
		/// <returns></returns>
		const TreeNode& _FindMax(const TreeNode& refTreeNode) const;
		TreeNode& _FindMax(TreeNode& refTreeNode);
		/// <summary>
		/// ��ýڵ�����С��ֵ
		/// </summary>
		/// <param name="refTreeNode"></param>
		/// <returns></returns>
		const TreeNode& _FindMin(const TreeNode& refTreeNode) const;
		TreeNode& _FindMin(TreeNode& refTreeNode);
		/// <summary>
		/// ����
		/// </summary>
		/// <param name="dwTreeNodeIndex"></param>
		/// <param name="k"></param>
		/// <returns></returns>
		iterator _Find(unsigned int dwTreeNodeIndex, const _K& k);
		/// <summary>
		/// _LowerBound
		/// </summary>
		/// <param name="refIterator">����ֵ</param>
		/// <param name="dwTreeNodeIndex"></param>
		/// <param name="k"></param>
		/// <returns></returns>
		iterator _LowerBound(iterator& refIterator, unsigned int dwTreeNodeIndex, const _K& k);
		/// <summary>
		/// _uPPERbOund
		/// </summary>
		/// <param name="refIterator">����ֵ</param>
		/// <param name="dwTreeNodeIndex"></param>
		/// <param name="k"></param>
		/// <returns></returns>
		iterator _UpperBound(iterator& refIterator, unsigned int dwTreeNodeIndex, const _K& k);
		/// <summary>
		/// ��r�ڵ�ŵ�l�ڵ��У����ӹ�ϵ��ֵ���ɣ�
		/// </summary>
		/// <param name="l"></param>
		/// <param name="r"></param>
		void _ReplaceTreeNode4Erase(TreeNode& l, TreeNode& r);
		/// <summary>
		/// ��r�ڵ�ָ���ֵ�ŵ�l�ڵ�ָ���ֵ��
		/// </summary>
		/// <param name="l"></param>
		/// <param name="r"></param>
		void _CopyValueNode4Erase(TreeNode& l, TreeNode& r);
		/// <summary>
		/// ��ȡ��һ��
		/// </summary>
		/// <param name="refTreeNode"></param>
		/// <returns></returns>
		iterator _GetNext(const TreeNode& refTreeNode);
		const_iterator _GetNext(const TreeNode& refTreeNode)const;
		/// <summary>
		/// ���ϲ�����һ��(��ǰ�ڵ�Ϊ���ӽڵ�ʱ�ĸ��ڵ�)
		/// </summary>
		/// <param name="refTreeNode"></param>
		/// <returns></returns>
		iterator _GetNext4Parent(TreeNode& refTreeNode);
		const_iterator _GetNext4Parent(TreeNode& refTreeNode)const;
		/// <summary>
		///	��ȡ��һ��
		/// </summary>
		/// <param name="refTreeNode"></param>
		/// <returns></returns>
		iterator _GetPrevious(const TreeNode& refTreeNode);
		/// <summary>
		/// ���ϲ�����һ��(��ǰ�ڵ�Ϊ���ӽڵ�ʱ�ĸ��ڵ�)
		/// </summary>
		/// <param name="refTreeNode"></param>
		/// <returns></returns>
		iterator _GetPrevious4Parent(const TreeNode& refTreeNode);
		/// <summary>
		/// ��ȡ�ýڵ��������ӽڵ������
		/// </summary>
		/// <param name="dwTreeNodeIndex"></param>
		/// <returns></returns>
		unsigned int _GetNodeNum(unsigned int dwTreeNodeIndex) const;
		/// <summary>
		/// �������
		/// </summary>
		/// <param name="dwCompareIndex">��ѯ�ȽϵĽڵ�</param>
		/// <param name="refValue"></param>
		/// <returns></returns>
		insert_ret _Insert(unsigned int dwCompareIndex, const typename Alloc::ValueType& refValue);
		/// <summary>
		/// �������
		/// </summary>
		/// <param name="it_ret"></param>
		/// <param name="dwSearchIndex">��ѯ�ȽϵĽڵ�</param>
		/// <param name="dwIndex">������ڵ�</param>
		/// <returns></returns>
		void _Insert(insert_ret& it_ret, unsigned int& dwCompareIndex, unsigned int dwCompareParentIndex, unsigned int dwIndex);
		/// <summary>
		/// ɾ���ڵ�
		/// </summary>
		/// <param name="dwCompareIndex">������ڵ㿪ʼ����</param>
		/// <param name="k"></param>
		/// <returns></returns>
		iterator _Erase(unsigned int dwCompareIndex, const _K& k);
		/// <summary>
		/// ɾ���ýڵ������нڵ�
		/// </summary>
		/// <param name="refTreeNode"></param>
		void _Clear(TreeNode& refTreeNode);
		/// <summary>
		/// ����ת ��
		/// </summary>
		/// <param name="refTreeNode">Ҫ��ת�Ľڵ�</param>
		/// <returns>��ת��������λ�õĽڵ�</returns>
		unsigned int _LL(TreeNode& refTreeNode);
		/// <summary>
		/// ����ת ��
		/// </summary>
		/// <param name="refTreeNode">Ҫ��ת�Ľڵ�</param>
		/// <returns></returns>
		unsigned int _RR(TreeNode& refTreeNode);
		/// <summary>
		/// ˫��ת ����
		/// </summary>
		/// <param name="refTreeNode">Ҫ��ת�Ľڵ�</param>
		/// <returns></returns>
		unsigned int _LR(TreeNode& refTreeNode);
		/// <summary>
		/// ˫��ת ����
		/// </summary>
		/// <param name="refTreeNode">Ҫ��ת�Ľڵ�</param>
		/// <returns></returns>
		unsigned int _RL(TreeNode& refTreeNode);

		ShmPool<TreeNodeData, Alloc::CAPACITY> m_oNodePool;

		unsigned int				m_dwRootIndex;
		unsigned int				m_dwSize;
	};

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::create()
	{
		m_dwSize = 0;
		m_oNodePool.create();
		m_dwRootIndex = Alloc::CAPACITY;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::insert_ret Tree<_K, Alloc, KeyLess>::insert(const typename Alloc::ValueType& refValue)
	{
		return _Insert(m_dwRootIndex, refValue);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline unsigned int Tree<_K, Alloc, KeyLess>::erase(const _K& k)
	{
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			return 0;
		}
		if (end() != _Erase(m_dwRootIndex, k))
		{
			return 1;
		}
		return 0;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::erase(iterator it)
	{
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			return end();
		}
		return _Erase(m_dwRootIndex, it->first);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::erase(const_iterator it)
	{
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			return end();
		}
		return _Erase(m_dwRootIndex, it->first);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::find(const _K& k)
	{
		return _Find(m_dwRootIndex, k);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::begin()
	{
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			return end();
		}
		TreeNode& refTreNode = _GetTreeNode(m_dwRootIndex);
		TreeNode& refBeginTreeNode = _FindMin(refTreNode);
		iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &refBeginTreeNode;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::const_iterator Tree<_K, Alloc, KeyLess>::cbegin() const
	{
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			return cend();
		}
		const TreeNode& refTreNode = _GetTreeNode(m_dwRootIndex);
		const TreeNode& refBeginTreeNode = _FindMin(refTreNode);
		const_iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &refBeginTreeNode;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::end()
	{
		iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &_GetTreeNode(0) + Alloc::CAPACITY;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::const_iterator Tree<_K, Alloc, KeyLess>::cend() const
	{
		const_iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &_GetTreeNode(0) + Alloc::CAPACITY;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::reverse_iterator Tree<_K, Alloc, KeyLess>::rbegin()
	{
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			return rend();
		}
		TreeNode& refTreNode = _GetTreeNode(m_dwRootIndex);
		TreeNode& refBeginTreeNode = _FindMax(refTreNode);
		reverse_iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &refBeginTreeNode;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::const_reverse_iterator Tree<_K, Alloc, KeyLess>::crbegin() const
	{
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			return crend();
		}
		const TreeNode& refTreNode = _GetTreeNode(m_dwRootIndex);
		const TreeNode& refBeginTreeNode = _FindMax(refTreNode);
		const_reverse_iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &refBeginTreeNode;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::reverse_iterator Tree<_K, Alloc, KeyLess>::rend()
	{
		reverse_iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &_GetTreeNode(0) - 1;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::const_reverse_iterator Tree<_K, Alloc, KeyLess>::crend() const
	{
		const_reverse_iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &_GetTreeNode(0) - 1;
		return it;
	}
	
	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::lower_bound(const _K& k)
	{
		iterator it = end();
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			return it;
		}
		_LowerBound(it, m_dwRootIndex, k);
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::upper_bound(const _K& k)
	{
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			return end();
		}
		iterator it = end();
		_UpperBound(it, m_dwRootIndex, k);
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::clear()
	{
		if (Alloc::CAPACITY != m_dwRootIndex)
		{
			_Clear(_GetTreeNode(m_dwRootIndex));
		}
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline unsigned int Tree<_K, Alloc, KeyLess>::size() const
	{
		assert(m_dwSize == _GetNodeNum(m_dwRootIndex));
		return m_dwSize;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::debug_info(std::ostream& os)
	{
		std::deque<unsigned int> tree_node_indexs[2];
		int deque_index = 0;
		tree_node_indexs[deque_index].push_back(m_dwRootIndex);
		while (!tree_node_indexs[deque_index].empty())
		{
			int next_deque_index = (deque_index + 1) % 2;
			unsigned int dwIndex = *tree_node_indexs[deque_index].begin();
			if ((dwIndex & 0x0000FFFF) == Alloc::CAPACITY)
			{
				unsigned int dwHeight = (dwIndex & 0xFFFF0000) >> 16;
				os << "0-" << dwHeight << ",";
				tree_node_indexs[deque_index].pop_front();
				if (tree_node_indexs[deque_index].empty())
				{
					deque_index = next_deque_index;
					os << "\n";
				}
				continue;
			}
			TreeNode& refTreeNode = _GetTreeNode(dwIndex);
			tree_node_indexs[deque_index].pop_front();
			if (Alloc::CAPACITY == refTreeNode.m_dwLeftIndex)
			{
				tree_node_indexs[next_deque_index].push_back(((refTreeNode.m_dwHeight - 1) << 16) | refTreeNode.m_dwLeftIndex);
			}
			else
			{
				tree_node_indexs[next_deque_index].push_back(refTreeNode.m_dwLeftIndex);
			}
			if (Alloc::CAPACITY == refTreeNode.m_dwRightIndex)
			{
				tree_node_indexs[next_deque_index].push_back(((refTreeNode.m_dwHeight - 1) << 16) | refTreeNode.m_dwRightIndex);
			}
			else
			{
				tree_node_indexs[next_deque_index].push_back(refTreeNode.m_dwRightIndex);
			}
			os << Alloc::get_compare_val(refTreeNode) << "-" << refTreeNode.m_dwHeight << ", ";
			if (tree_node_indexs[deque_index].empty())
			{
				deque_index = next_deque_index;
				os << "\n";
			}
		}
		os << "\n";
		os << "\n";
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::TreeNode& Tree<_K, Alloc, KeyLess>::_GetTreeNode(unsigned int dwIndex)
	{
		return *(TreeNode*)(&m_oNodePool.get_value(dwIndex));
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline const typename Tree<_K, Alloc, KeyLess>::TreeNode& Tree<_K, Alloc, KeyLess>::_GetTreeNode(unsigned int dwIndex) const
	{
		return *(TreeNode*)(&m_oNodePool.get_value(dwIndex));
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::_ConstructTreeNodeData(TreeNodeData& refTreeNodeData, unsigned int dwTreeNodeIndex)
	{
		refTreeNodeData.m_dwMyIndex = dwTreeNodeIndex;
		refTreeNodeData.m_dwParentIndex = Alloc::CAPACITY;
		refTreeNodeData.m_dwLeftIndex = Alloc::CAPACITY;
		refTreeNodeData.m_dwRightIndex = Alloc::CAPACITY;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::_ConstructTreeNodeData(
		TreeNodeData& refTreeNodeData, unsigned int dwTreeNodeIndex, const typename Alloc::ValueType& refValueNode)
	{
		*(typename Alloc::ValueType*)(&refTreeNodeData) = refValueNode;
		_ConstructTreeNodeData(refTreeNodeData, dwTreeNodeIndex);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline unsigned int Tree<_K, Alloc, KeyLess>::_BuyNode()
	{
		unsigned int dwNodeIndex = m_oNodePool.alloc();
		if (m_oNodePool.end() == dwNodeIndex)
		{
			throw(std::exception());
		}

		_ConstructTreeNodeData(m_oNodePool.get_value(dwNodeIndex), dwNodeIndex);

		++m_dwSize;
		return dwNodeIndex;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline unsigned int Tree<_K, Alloc, KeyLess>::_BuyNode(std::ostream os)
	{
		unsigned int dwNodeIndex = m_oNodePool.alloc(os);
		if (m_oNodePool.end() == dwNodeIndex)
		{
			os << "[" << __FILE__ << ", " << __LINE__ << ", " << __FUNCTION__ << "]\n";
			throw(std::exception());
		}

		_ConstructTreeNodeData(m_oNodePool.get_value(dwNodeIndex), dwNodeIndex);

		++m_dwSize;
		return dwNodeIndex;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline bool Tree<_K, Alloc, KeyLess>::_FreeNode(unsigned int dwTreeNodeIndex)
	{
		_ConstructTreeNodeData(m_oNodePool.get_value(dwTreeNodeIndex), dwTreeNodeIndex);
		if (!m_oNodePool.release(dwTreeNodeIndex))
		{
			throw(std::exception());
		}

		--m_dwSize;
		return true;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline bool Tree<_K, Alloc, KeyLess>::_FreeNode(unsigned int dwTreeNodeIndex, std::ostream& os)
	{
		_ConstructTreeNodeData(m_oNodePool.get_value(dwTreeNodeIndex), dwTreeNodeIndex);
		if (!m_oNodePool.release(dwTreeNodeIndex, os))
		{
			os << "[" << __FILE__ << ", " << __LINE__ << ", " << __FUNCTION__ << "]\n";
			throw(std::exception());
		}

		--m_dwSize;
		return true;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline bool Tree<_K, Alloc, KeyLess>::_Less(unsigned int dwLeftNodeIndex, unsigned int dwRoightNodeIndex) const
	{
		const TreeNode& refLeftNode = _GetTreeNode(dwLeftNodeIndex);
		const TreeNode& refRightNode = _GetTreeNode(dwRoightNodeIndex);

		return KeyLess()(Alloc::get_compare_val(refLeftNode), Alloc::get_compare_val(refRightNode));
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline bool Tree<_K, Alloc, KeyLess>::_Less4K(const _K& l, const _K& r) const
	{
		return KeyLess()(l, r);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline bool Tree<_K, Alloc, KeyLess>::_Equal4K(const _K& l, const _K& r) const
	{
		return !KeyLess()(l, r) && !KeyLess()(r, l);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::_RemoveNode(TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY != refTreeNode.m_dwParentIndex)
		{
			TreeNode& refParentTreeNode = _GetTreeNode(refTreeNode.m_dwParentIndex);
			if (refParentTreeNode.m_dwLeftIndex == refTreeNode.m_dwMyIndex)
			{
				refParentTreeNode.m_dwLeftIndex = Alloc::CAPACITY;
			}
			else if (refParentTreeNode.m_dwRightIndex == refTreeNode.m_dwMyIndex)
			{
				refParentTreeNode.m_dwRightIndex = Alloc::CAPACITY;
			}
			else
			{
				assert(0);
			}
		}
		_FreeNode(refTreeNode.m_dwMyIndex);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_GetIterator(TreeNode& refTreeNode)
	{
		iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &refTreeNode;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::const_iterator Tree<_K, Alloc, KeyLess>::_GetIterator(TreeNode& refTreeNode) const
	{
		const_iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &refTreeNode;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_GetIterator(unsigned int dwTreeNodeIndex)
	{
		if (dwTreeNodeIndex == Alloc::CAPACITY)
		{
			return end();
		}
		TreeNode& refTreeNode = _GetTreeNode(dwTreeNodeIndex);
		iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &refTreeNode;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::const_iterator Tree<_K, Alloc, KeyLess>::_GetIterator(unsigned int dwTreeNodeIndex) const
	{
		if (dwTreeNodeIndex == Alloc::CAPACITY)
		{
			return cend();
		}
		const TreeNode& refTreeNode = _GetTreeNode(dwTreeNodeIndex);
		const_iterator it;
		it.m_pTree = this;
		it.m_pTreeNode = &refTreeNode;
		return it;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline int Tree<_K, Alloc, KeyLess>::_GetHeight(unsigned int dwIndex)
	{
		if (Alloc::CAPACITY == dwIndex)
		{
			return 0;
		}
		TreeNode& refTreeNode = _GetTreeNode(dwIndex);
		return refTreeNode.m_dwHeight;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::_UpdateHeight(TreeNode& refTreeNode)
	{
		refTreeNode.m_dwHeight = std::max(_GetHeight(refTreeNode.m_dwLeftIndex), _GetHeight(refTreeNode.m_dwRightIndex)) + 1;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline const typename Tree<_K, Alloc, KeyLess>::TreeNode& Tree<_K, Alloc, KeyLess>::_FindMax(const TreeNode& refTreeNode) const
	{
		if (Alloc::CAPACITY == refTreeNode.m_dwRightIndex)
		{
			return refTreeNode;
		}
		const TreeNode& refRightTreeNode = _GetTreeNode(refTreeNode.m_dwRightIndex);
		return _FindMax(refRightTreeNode);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::TreeNode& Tree<_K, Alloc, KeyLess>::_FindMax(TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY == refTreeNode.m_dwRightIndex)
		{
			return refTreeNode;
		}
		TreeNode& refRightTreeNode = _GetTreeNode(refTreeNode.m_dwRightIndex);
		return _FindMax(refRightTreeNode);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline const typename Tree<_K, Alloc, KeyLess>::TreeNode& Tree<_K, Alloc, KeyLess>::_FindMin(const TreeNode& refTreeNode) const
	{
		if (Alloc::CAPACITY == refTreeNode.m_dwLeftIndex)
		{
			return refTreeNode;
		}
		const TreeNode& refLeftTreeNode = _GetTreeNode(refTreeNode.m_dwLeftIndex);
		return _FindMin(refLeftTreeNode);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::TreeNode& Tree<_K, Alloc, KeyLess>::_FindMin(TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY == refTreeNode.m_dwLeftIndex)
		{
			return refTreeNode;
		}
		TreeNode& refLeftTreeNode = _GetTreeNode(refTreeNode.m_dwLeftIndex);
		return _FindMin(refLeftTreeNode);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_Find(unsigned int dwTreeNodeIndex, const _K& k)
	{
		if (Alloc::CAPACITY == dwTreeNodeIndex)
		{
			return end();
		}
		TreeNode& refTreeNode = _GetTreeNode(dwTreeNodeIndex);
		if (_Less4K(k, Alloc::get_compare_val(refTreeNode)))
		{
			return _Find(refTreeNode.m_dwLeftIndex, k);
		}
		else if (_Less4K(Alloc::get_compare_val(refTreeNode), k))
		{
			return _Find(refTreeNode.m_dwRightIndex, k);
		}
		return _GetIterator(refTreeNode);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_LowerBound(iterator& refIterator, unsigned int dwTreeNodeIndex, const _K& k)
	{
		if (Alloc::CAPACITY == dwTreeNodeIndex)
		{
			return refIterator;
		}
		TreeNode& refTreeNode = _GetTreeNode(dwTreeNodeIndex);
		if (_Less4K(k, Alloc::get_compare_val(refTreeNode)))
		{
			refIterator = _GetIterator(refTreeNode);
			return _LowerBound(refIterator, refTreeNode.m_dwLeftIndex, k);
		}
		else if (_Less4K(Alloc::get_compare_val(refTreeNode), k))
		{
			return _LowerBound(refIterator, refTreeNode.m_dwRightIndex, k);
		}

		refIterator = _GetIterator(refTreeNode);

		return refIterator;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_UpperBound(iterator& refIterator, unsigned int dwTreeNodeIndex, const _K& k)
	{
		if (Alloc::CAPACITY == dwTreeNodeIndex)
		{
			return refIterator;
		}
		TreeNode& refTreeNode = _GetTreeNode(dwTreeNodeIndex);
		if (_Less4K(k, Alloc::get_compare_val(refTreeNode)))
		{
			refIterator = _GetIterator(refTreeNode);
			return _UpperBound(refIterator, refTreeNode.m_dwLeftIndex, k);
		}
		else
		{
			return _UpperBound(refIterator, refTreeNode.m_dwRightIndex, k);
		}

		assert(0);
		return refIterator;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::_ReplaceTreeNode4Erase(TreeNode& l, TreeNode& r)
	{
		if (l.m_dwRightIndex == r.m_dwMyIndex)
		{//��ֹ���õ��Լ� �ɻ�
			r.m_dwRightIndex = Alloc::CAPACITY;
		}
		else
		{
			r.m_dwRightIndex = l.m_dwRightIndex;
		}
		if (l.m_dwLeftIndex == r.m_dwMyIndex)
		{//��ֹ���õ��Լ� �ɻ�
			r.m_dwLeftIndex = Alloc::CAPACITY;
		}
		else
		{
			r.m_dwLeftIndex = l.m_dwLeftIndex;
		}

		//�����ӽڵ�ĸ�ָ��
		if (Alloc::CAPACITY != r.m_dwLeftIndex)
		{
			TreeNode& refLeftNode = _GetTreeNode(r.m_dwLeftIndex);
			refLeftNode.m_dwParentIndex = r.m_dwMyIndex;
		}
		if (Alloc::CAPACITY != r.m_dwRightIndex)
		{
			TreeNode& refRightNode = _GetTreeNode(r.m_dwRightIndex);
			refRightNode.m_dwParentIndex = r.m_dwMyIndex;
		}

		r.m_dwParentIndex = l.m_dwParentIndex;
		l.m_dwRightIndex = Alloc::CAPACITY;
		l.m_dwLeftIndex = Alloc::CAPACITY;

		if (Alloc::CAPACITY == l.m_dwParentIndex)
		{
			assert(l.m_dwMyIndex == m_dwRootIndex);
			m_dwRootIndex = r.m_dwMyIndex;
		}
		else
		{
			TreeNode& refParent = _GetTreeNode(r.m_dwParentIndex);
			if (refParent.m_dwLeftIndex == l.m_dwMyIndex)
			{
				refParent.m_dwLeftIndex = r.m_dwMyIndex;
			}
			else if (refParent.m_dwRightIndex == l.m_dwMyIndex)
			{
				refParent.m_dwRightIndex = r.m_dwMyIndex;
			}
			else
			{
				assert(0);
			}
		}
		l.m_dwParentIndex = Alloc::CAPACITY;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::_CopyValueNode4Erase(TreeNode& l, TreeNode& r)
	{
		*(typename Alloc::ValueType*)(&l) = *(typename Alloc::ValueType*)(&r);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_GetNext(const TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY != refTreeNode.m_dwRightIndex)
		{
			return _GetIterator(_FindMin(_GetTreeNode(refTreeNode.m_dwRightIndex)));
		}
		else
		{
			if (Alloc::CAPACITY == refTreeNode.m_dwParentIndex)
			{
				return end();
			}
			TreeNode& refParentTreeNode = _GetTreeNode(refTreeNode.m_dwParentIndex);
			if (refParentTreeNode.m_dwLeftIndex == refTreeNode.m_dwMyIndex)
			{
				return _GetIterator(refParentTreeNode);
			}
			else if (refParentTreeNode.m_dwRightIndex == refTreeNode.m_dwMyIndex)
			{
				return _GetNext4Parent(refParentTreeNode);
			}
			else
			{
				assert(0);
			}
		}

		assert(0);
		return iterator();
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::const_iterator Tree<_K, Alloc, KeyLess>::_GetNext(const TreeNode& refTreeNode) const
	{
		if (Alloc::CAPACITY != refTreeNode.m_dwRightIndex)
		{
			return _GetIterator(_FindMin(_GetTreeNode(refTreeNode.m_dwRightIndex)));
		}
		else
		{
			if (Alloc::CAPACITY == refTreeNode.m_dwParentIndex)
			{
				return cend();
			}
			TreeNode& refParentTreeNode = _GetTreeNode(refTreeNode.m_dwParentIndex);
			if (refParentTreeNode.m_dwLeftIndex == refTreeNode.m_dwMyIndex)
			{
				return _GetIterator(refParentTreeNode);
			}
			else if (refParentTreeNode.m_dwRightIndex == refTreeNode.m_dwMyIndex)
			{
				return _GetNext4Parent(refParentTreeNode);
			}
			else
			{
				assert(0);
			}
		}

		assert(0);
		return iterator();
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_GetNext4Parent(TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY == refTreeNode.m_dwParentIndex)
		{
			return end();
		}
		TreeNode& refParentTreeNode = _GetTreeNode(refTreeNode.m_dwParentIndex);
		if (refParentTreeNode.m_dwLeftIndex == refTreeNode.m_dwMyIndex)
		{
			return _GetIterator(refParentTreeNode);
		}
		else if (refParentTreeNode.m_dwRightIndex == refTreeNode.m_dwMyIndex)
		{
			return _GetNext4Parent(refParentTreeNode);
		}
		assert(0);
		return iterator();
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::const_iterator Tree<_K, Alloc, KeyLess>::_GetNext4Parent(TreeNode& refTreeNode) const
	{
		if (Alloc::CAPACITY == refTreeNode.m_dwParentIndex)
		{
			return cend();
		}
		TreeNode& refParentTreeNode = _GetTreeNode(refTreeNode.m_dwParentIndex);
		if (refParentTreeNode.m_dwLeftIndex == refTreeNode.m_dwMyIndex)
		{
			return _GetIterator(refParentTreeNode);
		}
		else if (refParentTreeNode.m_dwRightIndex == refTreeNode.m_dwMyIndex)
		{
			return _GetNext4Parent(refParentTreeNode);
		}
		assert(0);
		return const_iterator();
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_GetPrevious(const TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY != refTreeNode.m_dwLeftIndex)
		{
			return _GetIterator(_FindMax(_GetTreeNode(refTreeNode.m_dwLeftIndex)));
		}
		else
		{
			if (Alloc::CAPACITY == refTreeNode.m_dwParentIndex)
			{
				return end();
			}
			TreeNode& refParentTreeNode = _GetTreeNode(refTreeNode.m_dwParentIndex);
			if (refParentTreeNode.m_dwRightIndex == refTreeNode.m_dwMyIndex)
			{
				return _GetIterator(refParentTreeNode);
			}
			else if (refParentTreeNode.m_dwLeftIndex == refTreeNode.m_dwMyIndex)
			{
				return _GetPrevious4Parent(refParentTreeNode);
			}
			else
			{
				assert(0);
			}
		}

		assert(0);
		return iterator();
	}
	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_GetPrevious4Parent(const TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY == refTreeNode.m_dwParentIndex)
		{
			return end();
		}
		TreeNode& refParentTreeNode = _GetTreeNode(refTreeNode.m_dwParentIndex);
		if (refParentTreeNode.m_dwRightIndex == refTreeNode.m_dwMyIndex)
		{
			return _GetIterator(refParentTreeNode);
		}
		else if (refParentTreeNode.m_dwLeftIndex == refTreeNode.m_dwMyIndex)
		{
			return _GetNext4Parent(refParentTreeNode);
		}
		assert(0);
		return iterator();
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline unsigned int Tree<_K, Alloc, KeyLess>::_GetNodeNum(unsigned int dwTreeNodeIndex) const
	{
		if (Alloc::CAPACITY == dwTreeNodeIndex)
		{
			return 0;
		}
		const TreeNode& refTreeNode = _GetTreeNode(dwTreeNodeIndex);
		return _GetNodeNum(refTreeNode.m_dwLeftIndex) + _GetNodeNum(refTreeNode.m_dwRightIndex) + 1;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::insert_ret Tree<_K, Alloc, KeyLess>::_Insert(
		unsigned int dwCompareIndex, const typename Alloc::ValueType& v)
	{
		unsigned int dwNodeIndex = _BuyNode();
		TreeNodeData& refTreeNodeData = m_oNodePool.get_value(dwNodeIndex);
		_ConstructTreeNodeData(refTreeNodeData, dwNodeIndex, v);
		TreeNode* pTreeNode = (TreeNode*)(&refTreeNodeData);

		typename Tree<_K, Alloc, KeyLess>::insert_ret it_ret;
		it_ret.first.m_pTreeNode = pTreeNode;
		it_ret.first.m_pTree = this;
		it_ret.second = false;
		_Insert(it_ret, dwCompareIndex, Alloc::CAPACITY, dwNodeIndex);

		if (!it_ret.second)
		{
			_FreeNode(dwNodeIndex);
		}
		return it_ret;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::_Insert(
		typename Tree<_K, Alloc, KeyLess>::insert_ret& it_ret
		, unsigned int& dwCompareIndex, unsigned int dwCompareParentIndex, unsigned int dwIndex)
	{
		TreeNode& refTreeNode = _GetTreeNode(dwIndex);
		if (Alloc::CAPACITY == m_dwRootIndex)
		{
			m_dwRootIndex = dwIndex;
			refTreeNode.m_dwHeight = 1;
			it_ret.second = true;
		}
		else if (Alloc::CAPACITY == dwCompareIndex)
		{
			dwCompareIndex = dwIndex;
			refTreeNode.m_dwParentIndex = dwCompareParentIndex;
			refTreeNode.m_dwHeight = 1;
			it_ret.second = true;
		}
		else if (_Less(dwIndex, dwCompareIndex))
		{
			TreeNode& refCompareTreeNode = _GetTreeNode(dwCompareIndex);
			_Insert(it_ret, refCompareTreeNode.m_dwLeftIndex, dwCompareIndex, dwIndex);

			//�ж�ƽ�����
			if (_GetHeight(refCompareTreeNode.m_dwLeftIndex) - _GetHeight(refCompareTreeNode.m_dwRightIndex) > 1)
			{
				//��������� ���������
				if (_Less(dwIndex, refCompareTreeNode.m_dwLeftIndex))	//����
				{
					_LL(refCompareTreeNode);
				}
				else													//����
				{
					_LR(refCompareTreeNode);
				}
			}
			else
			{
				_UpdateHeight(refCompareTreeNode);
			}
		}
		else if (_Less(dwCompareIndex, dwIndex))
		{
			TreeNode& refCompareTreeNode = _GetTreeNode(dwCompareIndex);
			_Insert(it_ret, refCompareTreeNode.m_dwRightIndex, dwCompareIndex, dwIndex);

			if (_GetHeight(refCompareTreeNode.m_dwRightIndex) - _GetHeight(refCompareTreeNode.m_dwLeftIndex) > 1)
			{

				if (_Less(refCompareTreeNode.m_dwRightIndex, dwIndex))
				{
					_RR(refCompareTreeNode);
				}
				else
				{
					_RL(refCompareTreeNode);
				}
			}
			else
			{
				_UpdateHeight(refCompareTreeNode);
			}
		}
		else
		{
			//�ظ�����
			it_ret.second = false;
		}
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline typename Tree<_K, Alloc, KeyLess>::iterator Tree<_K, Alloc, KeyLess>::_Erase(unsigned int dwCompareIndex, const _K& k)
	{
		TreeNode& refTreeNode = _GetTreeNode(dwCompareIndex);
		//�ҵ���Ҫɾ���Ľ��
		if (_Equal4K(Alloc::get_compare_val(refTreeNode), k))
		{
			//�����������ǿ�
			if (refTreeNode.m_dwLeftIndex != Alloc::CAPACITY && refTreeNode.m_dwRightIndex != Alloc::CAPACITY)
			{//�ڸ߶ȸ�����Ǹ������Ͻ���ɾ������

				//�������߶ȴ�ɾ����������ֵ���Ľ�㣬���丳�������
				if (_GetHeight(refTreeNode.m_dwLeftIndex) > _GetHeight(refTreeNode.m_dwRightIndex))
				{
					TreeNode& refLeftNode = _GetTreeNode(refTreeNode.m_dwLeftIndex);
					TreeNode& refLeftMaxNode = _FindMax(refLeftNode);
					TreeNode& refTempNode = _GetTreeNode(_BuyNode());
					_ReplaceTreeNode4Erase(refTreeNode, refTempNode);
					_CopyValueNode4Erase(refTempNode, refLeftMaxNode);
					_RemoveNode(refTreeNode);
					_Erase(refTempNode.m_dwLeftIndex, Alloc::get_compare_val(refLeftMaxNode));

					_UpdateHeight(refTempNode);

					std::cout << _GetIterator(_FindMin(_GetTreeNode(refTempNode.m_dwRightIndex)))->first << "\n";
					assert(_GetIterator(_FindMin(_GetTreeNode(refTempNode.m_dwRightIndex)))->first > k);
					return _GetIterator(_FindMin(_GetTreeNode(refTempNode.m_dwRightIndex)));
				}
				else//�������߶ȸ���ɾ����������ֵ��С�Ľ�㣬���丳�������
				{
					TreeNode& refRightNode = _GetTreeNode(refTreeNode.m_dwRightIndex);
					TreeNode& refRightMinNode = _FindMin(refRightNode);
					TreeNode& refTempNode = _GetTreeNode(_BuyNode());
					_ReplaceTreeNode4Erase(refTreeNode, refTempNode);
					_CopyValueNode4Erase(refTempNode, refRightMinNode);
					_RemoveNode(refTreeNode);
					_Erase(refTempNode.m_dwRightIndex, Alloc::get_compare_val(refRightMinNode));

					_UpdateHeight(refTempNode);

					std::cout << _GetIterator(refTempNode)->first << "\n";
					assert(_GetIterator(refTempNode)->first > k);
					return _GetIterator(refTempNode);
				}
			}
			else
			{//����������һ����Ϊ�գ�ֱ������Ҫɾ���Ľ����ӽ���滻����
				iterator it = _GetNext(refTreeNode);
				if (Alloc::CAPACITY != refTreeNode.m_dwLeftIndex)
				{
					iterator it = _GetNext(refTreeNode);
					TreeNode& refLeftNode = _GetTreeNode(refTreeNode.m_dwLeftIndex);
					_ReplaceTreeNode4Erase(refTreeNode, refLeftNode);
					_RemoveNode(refTreeNode);
					std::cout << it->first << "\n";
					assert((it->first >= k) || (it == end()));
					return it;
				}
				else if (Alloc::CAPACITY != refTreeNode.m_dwRightIndex)
				{
					TreeNode& refRightNode = _GetTreeNode(refTreeNode.m_dwRightIndex);
					_ReplaceTreeNode4Erase(refTreeNode, refRightNode);
					_RemoveNode(refTreeNode);
					std::cout << it->first << "\n";
					assert((it->first >= k) || (it == end()));
					return _GetIterator(refRightNode);
				}
				else if (m_dwRootIndex == dwCompareIndex)
				{
					m_dwRootIndex = Alloc::CAPACITY;
					std::cout << "aaaddd" << "\n";
					_RemoveNode(refTreeNode);
					return it;
				}
				_RemoveNode(refTreeNode);
				std::cout << it->first << "\n";
				assert((it->first >= k) || (it == end()));
				return it;
			}
		}
		else if (_Less4K(k, Alloc::get_compare_val(refTreeNode)))//Ҫɾ���Ľ������������
		{
			//�ݹ�ɾ���������ϵĽ��
			if (Alloc::CAPACITY == refTreeNode.m_dwLeftIndex)
			{
				return end();
			}
			iterator it = _Erase(refTreeNode.m_dwLeftIndex, k);
			//�ж��Ƿ���Ȼ����ƽ������
			if (_GetHeight(refTreeNode.m_dwRightIndex) - _GetHeight(refTreeNode.m_dwLeftIndex) > 1)
			{
				TreeNode& refRightNode = _GetTreeNode(refTreeNode.m_dwRightIndex);
				if (_GetHeight(refRightNode.m_dwLeftIndex) > _GetHeight(refRightNode.m_dwRightIndex))
				{
					//RL˫��ת
					_RL(refTreeNode);
				}
				else
				{//RR����ת
					_RR(refTreeNode);
				}
			}
			else//����ƽ������ �����߶���Ϣ
			{
				_UpdateHeight(refTreeNode);
			}
			return it;
		}
		else if (_Less4K(Alloc::get_compare_val(refTreeNode), k))//Ҫɾ���Ľ������������
		{
			//�ݹ�ɾ�����������
			if (Alloc::CAPACITY == refTreeNode.m_dwRightIndex)
			{
				return end();
			}
			iterator it = _Erase(refTreeNode.m_dwRightIndex, k);
			//�ж�ƽ�����
			if (_GetHeight(refTreeNode.m_dwLeftIndex) - _GetHeight(refTreeNode.m_dwRightIndex) > 1)
			{
				TreeNode& refLeftNode = _GetTreeNode(refTreeNode.m_dwLeftIndex);
				if (_GetHeight(refLeftNode.m_dwRightIndex) > _GetHeight(refLeftNode.m_dwLeftIndex))
				{
					//LR˫��ת
					_LR(refTreeNode);
				}
				else
				{
					//LL����ת
					_LL(refTreeNode);
				}
			}
			else//����ƽ���� �����߶�
			{
				_UpdateHeight(refTreeNode);
			}
			return it;
		}
		return end();
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline void Tree<_K, Alloc, KeyLess>::_Clear(TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY != refTreeNode.m_dwRightIndex)
		{
			TreeNode& refRightTreeNode = _GetTreeNode(refTreeNode.m_dwRightIndex);
			_Clear(refRightTreeNode);
		}
		if (Alloc::CAPACITY != refTreeNode.m_dwLeftIndex)
		{
			TreeNode& refLeftTreeNode = _GetTreeNode(refTreeNode.m_dwLeftIndex);
			_Clear(refLeftTreeNode);
		}
		if (refTreeNode.m_dwMyIndex == m_dwRootIndex)
		{
			m_dwRootIndex = Alloc::CAPACITY;
		}
		_RemoveNode(refTreeNode);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline unsigned int Tree<_K, Alloc, KeyLess>::_LL(TreeNode& refTreeNode)
	{
		//refTreeNodeΪ�������������ʧ��Ľ��

		//��ȡʧ���������
		TreeNode& refLeftSon = _GetTreeNode(refTreeNode.m_dwLeftIndex);
		//����son����Һ��ӵĸ�ָ��
		if (Alloc::CAPACITY != refLeftSon.m_dwRightIndex)
		{
			TreeNode& refSonRightChild = _GetTreeNode(refLeftSon.m_dwRightIndex);
			//����son����Һ��ӵĸ�ָ��
			refSonRightChild.m_dwParentIndex = refTreeNode.m_dwMyIndex;
		}
		//ʧ��������ӱ��Ϊson���Һ���
		refTreeNode.m_dwLeftIndex = refLeftSon.m_dwRightIndex;
		//����ʧ����ĸ߶���Ϣ
		_UpdateHeight(refTreeNode);
		//ʧ������son���Һ���
		refLeftSon.m_dwRightIndex = refTreeNode.m_dwMyIndex;
		//����son�ĸ����Ϊԭʧ����ĸ����
		refLeftSon.m_dwParentIndex = refTreeNode.m_dwParentIndex;
		//���ʧ���㲻�Ǹ���㣬��ʼ���¸��ڵ�
		if (Alloc::CAPACITY != refTreeNode.m_dwParentIndex)
		{
			//��ȡʧ����ĸ��ڵ�
			TreeNode& refParent = _GetTreeNode(refTreeNode.m_dwParentIndex);
			//������ڵ��������ʧ���㣬ָ�����ڸ��º���º���son
			if (refParent.m_dwLeftIndex == refTreeNode.m_dwMyIndex)
			{
				refParent.m_dwLeftIndex = refLeftSon.m_dwMyIndex;
			}
			else if (refParent.m_dwRightIndex == refTreeNode.m_dwMyIndex)
			{
				//���ڵ���Һ�����ʧ����
				refParent.m_dwRightIndex = refLeftSon.m_dwMyIndex;
			}
			else
			{
				assert(0);
			}
		}
		else
		{
			m_dwRootIndex = refLeftSon.m_dwMyIndex;
		}
		//����ʧ����ĸ���
		refTreeNode.m_dwParentIndex = refLeftSon.m_dwMyIndex;
		//����son���ĸ߶���Ϣ
		_UpdateHeight(refLeftSon);
		return refLeftSon.m_dwMyIndex;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline unsigned int Tree<_K, Alloc, KeyLess>::_RR(TreeNode& refTreeNode)
	{
		//refTreeNodeΪ�������������ʧ��Ľ��

		//��ȡʧ������Һ���
		TreeNode& refRightSon = _GetTreeNode(refTreeNode.m_dwRightIndex);
		//����son������ӵĸ�ָ��
		if (Alloc::CAPACITY != refRightSon.m_dwLeftIndex)
		{
			TreeNode& refSonLeftChild = _GetTreeNode(refRightSon.m_dwLeftIndex);
			//����son������ӵĸ�ָ��
			refSonLeftChild.m_dwParentIndex = refTreeNode.m_dwMyIndex;
		}
		//ʧ������Һ��ӱ��Ϊson������
		refTreeNode.m_dwRightIndex = refRightSon.m_dwLeftIndex;
		//����ʧ����ĸ߶���Ϣ
		_UpdateHeight(refTreeNode);
		//ʧ������son������
		refRightSon.m_dwLeftIndex = refTreeNode.m_dwMyIndex;
		//����son�ĸ����Ϊԭʧ����ĸ����
		refRightSon.m_dwParentIndex = refTreeNode.m_dwParentIndex;
		//���ʧ���㲻�Ǹ���㣬��ʼ���¸��ڵ�
		if (Alloc::CAPACITY != refTreeNode.m_dwParentIndex)
		{
			//��ȡʧ����ĸ��ڵ�
			TreeNode& refParent = _GetTreeNode(refTreeNode.m_dwParentIndex);
			//������ڵ��������ʧ���㣬ָ�����ڸ��º���º���son
			if (refParent.m_dwLeftIndex == refTreeNode.m_dwMyIndex)
			{
				refParent.m_dwLeftIndex = refRightSon.m_dwMyIndex;
			}
			else if (refParent.m_dwRightIndex == refTreeNode.m_dwMyIndex)
			{
				//���ڵ���Һ�����ʧ����
				refParent.m_dwRightIndex = refRightSon.m_dwMyIndex;
			}
			else
			{
				assert(0);
			}
		}
		else
		{
			m_dwRootIndex = refRightSon.m_dwMyIndex;
		}
		//����ʧ����ĸ���
		refTreeNode.m_dwParentIndex = refRightSon.m_dwMyIndex;
		//����son���ĸ߶���Ϣ
		_UpdateHeight(refRightSon);
		return refRightSon.m_dwMyIndex;
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline unsigned int Tree<_K, Alloc, KeyLess>::_LR(TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY != refTreeNode.m_dwLeftIndex)
		{
			_RR(_GetTreeNode(refTreeNode.m_dwLeftIndex));
		}
		return _LL(refTreeNode);
	}

	template<typename _K, typename Alloc, typename KeyLess>
	inline unsigned int Tree<_K, Alloc, KeyLess>::_RL(TreeNode& refTreeNode)
	{
		if (Alloc::CAPACITY != refTreeNode.m_dwRightIndex)
		{
			_LL(_GetTreeNode(refTreeNode.m_dwRightIndex));
		}
		return _RR(refTreeNode);
	}
}

#endif // __SHARE_MEM_CONTAINER_TREE_H__

