﻿// shm_container.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "shm_pool.h"
#include "shm_container_tree.h"
#include "shm_container_map.h"

#include <vector>
#include <algorithm>
#include <thread>
#include <chrono>
#include <map>
#include <assert.h>
#include <iostream>

int main()
{
	ShareMemoryContainer::ShmPool<int, 1024> pool;
	pool.create();

	//ShareMemoryContainer::Tree<int, int, ShareMemoryContainer::allocator<ShareMemoryContainer::MapAllocator<int, int>, 1024> > tree;
	//tree.create();

	ShareMemoryContainer::map<int, int, 1024 > _map_test;
	_map_test.create();
	_map_test.cbegin();
	_map_test.cend();

	std::map<int, int> _map;
	//_map.cbegin();

	std::vector<int> _vec;

	srand(time(0));
	while (true)
	{
		for (int i = 0; i < 1020; ++i)
		{
			int f = rand();
			int s = rand();
			_vec.push_back(f);
			auto it_r1 = _map.insert({ f, s });
			auto it_r2 = _map_test.insert({f, s});
			assert(it_r1.second == it_r2.second);
			if (it_r1.second)
			{
				assert(it_r1.first->first == it_r2.first->first);
				assert(it_r1.first->second == it_r2.first->second);
			}
			assert(_map_test.size() == _map.size());
			std::cout << f << "\n";
			//_map_test.debug_info(std::cout);
		}
		for (auto p : _map)
		{
			assert(p.second == _map_test.find(p.first)->second);
		}

		auto it_1 = _map_test.begin();
		auto it_2 = _map.begin();
		while (true)
		{
			if (it_2 == _map.end())
			{
				assert(it_1 == _map_test.end());
				break;
			}
			assert(it_1->first == it_2->first);
			assert(it_1->second == it_2->second);
			++it_1;
			++it_2;
		}

		std::random_shuffle(_vec.begin(), _vec.end());

		for (auto p : _vec)
		{
			std::cout << "erase " << p << "\n";


			auto it1 = _map_test.find(p);
			auto it2 = _map.find(p);
			if (_map.end() != it2)
			{
				auto it11 = _map_test.erase(it1->first);
				auto it22 = _map.erase(it2);
				if (it22 == _map.end())
				{
					assert(it11 == _map_test.end());
				}
				else
				{
					assert(it11->second == it22->second);
				}
				//_map_test.debug_info(std::cout);
			}
		
			assert(_map_test.size() == _map.size());
			//_map_test.debug_info(std::cout);
		}
		_vec.clear();

		//std::vector<int> tmp;
		//for (int i = 0; i < tree.end(); ++i)
		//{
		//	tmp.push_back(tree._BuyNode());
		//}
		//std::random_shuffle(tmp.begin(), tmp.end());
		//for (int i = 0; i < tree.end(); ++i)
		//{
		//	tree._FreeNode(tmp[i]);
		//}

		std::this_thread::sleep_for(std::chrono::milliseconds(1));
	}

	std::map<int, int> m;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
