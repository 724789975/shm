#ifndef __SHARE_MEM_CONTAINER_MAP_H__
#define __SHARE_MEM_CONTAINER_MAP_H__

#include "shm_container_less.h"
#include "shm_pool.h"
#include "shm_container_tree.h"
#include "shm_container_map_alloctor.h"

//K, V ��֧��POD����
namespace ShareMemoryContainer
{

	template<typename K, typename V, unsigned int dwMaxNum, typename KeyLess = Less<K> >
	class map : public Tree<K, allocator<MapAllocator<K, V>, dwMaxNum>, KeyLess>
	{
	public:
		typedef Tree<K, allocator<MapAllocator<K, V>, dwMaxNum>, KeyLess> TreeType;
		typedef typename TreeType::iterator iterator;
		typedef const typename iterator const_iterator;
		typedef std::pair<iterator, bool> insert_ret;

		private:
	};
}

#endif // __SHARE_MEM_CONTAINER_MAP_H__

