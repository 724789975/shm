#ifndef __SHARE_MEM_CONTAINER_MAP_H__
#define __SHARE_MEM_CONTAINER_MAP_H__

#include "shm_container_less.h"
#include "shm_pool.h"
#include "shm_container_tree.h"
#include "shm_container_map_alloctor.h"

//K, V ��֧��POD����
namespace ShareMemoryContainer
{

	template<typename K, typename V, unsigned int dwMaxNum, typename KeyLess = Less<K> >
	class map : public Tree<K, allocator<MapAllocator<K, V>, dwMaxNum>, KeyLess>
	{
	public:
		typedef Tree<K, allocator<MapAllocator<K, V>, dwMaxNum>, KeyLess> TreeType;
		typedef typename TreeType::iterator iterator;
		typedef const typename iterator const_iterator;
		typedef std::pair<iterator, bool> insert_ret;

		V& operator[](const K& k);
		private:
	};
	template<typename K, typename V, unsigned int dwMaxNum, typename KeyLess>
	inline V& map<K, V, dwMaxNum, KeyLess>::operator[](const K& k)
	{
		iterator it = find(k);
		if (TreeType::end() == it)
		{
			auto it_ret = insert({ k, V() });
			if (it_ret)
			{
				it = it_ret.first;
			}
		}
		return it->second;
	}
}

#endif // __SHARE_MEM_CONTAINER_MAP_H__

